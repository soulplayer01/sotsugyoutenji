# 어른이 된 순간 — Prototype V2.2

현재 작업본: 연도별 자동 진행 및 상시 상태창 업데이트 포함.

## 실행
Node.js 22.12 이상을 권장합니다.
이 폴더에서 터미널을 열고 실행하세요.

```sh
npm ci
npm run dev -- --host 0.0.0.0
```
터미널에 표시되는 Local 또는 Network 주소를 엽니다. 개발 서버 터미널은 유지하세요.

## 검증 및 빌드
```sh
npm test
npm run build
npm run preview
```
배포용 파일은 빌드 후 dist 폴더에 생성됩니다.

현재 진입점은 src/life/NarrativeApp.jsx입니다.
기존 버전의 소스와 테스트도 src 및 tests에 보존되어 있습니다.
선택 기록은 메모리에만 유지되며 새로고침하거나 다시 시작하면 초기화됩니다.
실제 프린터 연결은 포함하지 않습니다.

node_modules, Git 이력, 임시 작업 파일, 원본 Excel은 이 ZIP에 포함하지 않았습니다.
리서치 기반 데이터와 출처 정보는 기존 소스 파일에 보존되어 있습니다.
